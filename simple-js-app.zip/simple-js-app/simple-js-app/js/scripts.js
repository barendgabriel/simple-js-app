alert('Hello world');
var favoriteFood = 'Pizza'; // Change 'Pizza' to whatever you like
document.write(favoriteFood);
